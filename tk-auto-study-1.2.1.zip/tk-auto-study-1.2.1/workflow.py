import main

if __name__ == '__main__':
    main.start_with_workflow()
